package pages.selenium;

//import java.time.Duration;

//import org.openqa.selenium.support.ui.WebDriverWait;

import lib.selenium.PreAndPost;

public class AppLauncher extends PreAndPost{

	 
	
	public AppLauncher ClickAppLauncher() {
		//WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));	
		click(locateElement("xpath","//button[contains(@class,'salesforceIdentityAppLauncherHeader')]"));
		return this;
	}

}