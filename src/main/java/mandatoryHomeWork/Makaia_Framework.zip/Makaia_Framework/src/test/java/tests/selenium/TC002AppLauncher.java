package tests.selenium;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Test;


import pages.selenium.AppLauncher;

public class TC002AppLauncher extends AppLauncher{
	
	@BeforeTest
	public void setValues() {
		testCaseName = "AppLauncher";
		testDescription = "AppLauncher";
		nodes = "Login";
		authors = "Shilviya";
		category = "UI";
		}
	
	@Test
	public void appLauncher() {
		new AppLauncher().
		ClickAppLauncher();
		//return this;
	}
	  
}