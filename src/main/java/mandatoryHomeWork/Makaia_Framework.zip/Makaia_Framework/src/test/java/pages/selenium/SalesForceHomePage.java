package pages.selenium;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import lib.selenium.PreAndPost;

public class SalesForceHomePage extends PreAndPost{

	public SalesForceHomePage(WebDriver driver, ExtentTest test) {	
		this.driver = driver;
		this.test = test;	
		driver.switchTo().defaultContent();
		PageFactory.initElements(driver, this);
	}		

	public SalesForceHomePage searchUsingFilter(String value) {	
		type(locateElement("filter"),value);
		return this; 
	}	
	
	
	@FindBy(linkText="Create New")
	WebElement eleCreateNew;	
	public CreateNewIncident clickCreateNew() {		
		try {
			Thread.sleep(5000);
		click(eleCreateNew);
		} catch (InterruptedException e) {
		}
		return new CreateNewIncident(driver, test); 
	}	
	

	@FindBy(linkText="Open")
	WebElement eleOpen;	
	public ListIncidents clickOpen() {		
		click(eleOpen);
		return new ListIncidents(driver, test); 
	}

	public SalesForceHomePage ClickAppLauncher() {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));	
		click(locateElement("xpath","//button[contains(@class,'salesforceIdentityAppLauncherHeader')]"));
		return this;
		
	}
	
	public SalesForceHomePage viewAllAndSearchMarketing(String searchValue) {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		click(locateElement("xpath","//button[contains(text(),'View All')]"));
		type(locateElement("xpath","//input[contains(@placeholder,'Search apps')]"),searchValue);
		click(locateElement("xpath","//mark[contains(text(),'Marketing')]"));
		return this;
	}
	
	
	
}










