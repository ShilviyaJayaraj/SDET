package tests.selenium;
import org.testng.annotations.Test;
//import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeTest;
import lib.selenium.PreAndPost;
import pages.selenium.LoginSF;

public class TC001Login extends PreAndPost{
	
	@BeforeTest
	public void setValues() {
		testCaseName = "Login";
		testDescription = "Login with valid credentials";
		nodes = "Login";
		authors = "Shilviya";
		category = "UI";
		}
	
	@Test
	public void tc001Login() throws FileNotFoundException, IOException {		
		Properties prop = new Properties();
		prop.load(new FileInputStream(new File("./src/test/resources/config.properties")));
		
		new LoginSF(driver, test).typeUserName(prop.getProperty("username"))
		.typePassword(prop.getProperty("password"))
		.clickLogIn()
		.ClickAppLauncher()
		.viewAllAndSearchMarketing("Marketing");
	}
	
	
	/*
	 * public void tcLeadCreate() { new SfLeadCreation(driver, test) .sFloginApp() }
	 */
}
