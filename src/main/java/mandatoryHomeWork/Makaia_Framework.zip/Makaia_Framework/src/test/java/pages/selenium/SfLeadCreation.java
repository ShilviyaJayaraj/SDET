package pages.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import lib.selenium.PreAndPost;

public class SfLeadCreation extends PreAndPost {
	
private Properties prop;
	
	public SfLeadCreation(WebDriver driver, ExtentTest test) {	
		this.driver = driver;
		this.test = test;
		//driver.switchTo().frame(0);
		PageFactory.initElements(driver,this);
		
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./src/test/resources/config.properties")));
		} catch (Exception e) {
			reportStep("Missing the configuration file", "FAIL");
		}
			
	}
	 
	@FindBy(className="slds-icon-waffle") 
	private WebElement appLauncher;	
	
	@FindBy(xpath="//button[text()='View All']")
	private WebElement viewAll;	
	
	@FindBy(xpath="//input[@part='input']")
	private WebElement enterAppName;

	
	
	private SfLeadCreation appLauncher() {	
		click(appLauncher);
		return this;
	}	

	
	private SfLeadCreation viewAll() {
		click(viewAll);
		return this;
	}	
	
	
	private HomePage enterAppName(String appName) {
		type(enterAppName, appName);
		return new HomePage(driver,test);		
	}
	
	public HomePage sFloginApp() {
		return 
		appLauncher()
		.viewAll()
		.enterAppName(prop.getProperty("appName"));		
	}
}
