package pages.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import lib.selenium.PreAndPost;

public class LoginSF extends PreAndPost {
	
private Properties prop;
	
	public LoginSF(WebDriver driver, ExtentTest test) {	
		this.driver = driver;
		this.test = test;
		//driver.switchTo().frame(0);
		PageFactory.initElements(driver,this);
		
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./src/test/resources/config.properties")));
		} catch (Exception e) {
			reportStep("Missing the configuration file", "FAIL");
		}
			
	}
	 
	@FindBy(id="username") 
	private WebElement eleUserName;	
	
	@FindBy(id="password")
	private WebElement elePassword;	
	
	@FindBy(how=How.ID,using="Login")
	private WebElement eleLogin;

	
	@Given("Enter username as (.*)$")
	public LoginSF typeUserName(String username) {	
		type(eleUserName, username);
		return this;
	}	

	@And("Enter password as (.*)$")
	public LoginSF typePassword(String password) {
		type(elePassword, password);
		return this;
	}	
	
	@Then("Click the Login")
	public SalesForceHomePage clickLogIn() {
		click(eleLogin);
		return new SalesForceHomePage(driver,test);		
	}
	
	public SalesForceHomePage sFloginApp() {
		return 
		typeUserName(prop.getProperty("username"))
		.typePassword(prop.getProperty("password"))
		.clickLogIn();
	}
}
